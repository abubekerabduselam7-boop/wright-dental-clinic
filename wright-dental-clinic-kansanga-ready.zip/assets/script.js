const menu = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");

if (menu) {
  menu.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menu.setAttribute("aria-expanded", open ? "true" : "false");
    menu.textContent = open ? "×" : "☰";
  });
}

document.querySelectorAll(".nav a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    if (menu) {
      menu.setAttribute("aria-expanded", "false");
      menu.textContent = "☰";
    }
  });
});

document.getElementById("year").textContent = new Date().getFullYear();
